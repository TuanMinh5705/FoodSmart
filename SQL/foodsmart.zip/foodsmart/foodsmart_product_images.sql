-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: foodsmart
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `image_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `image_path` text DEFAULT (_utf8mb4'product_default.png'),
  `is_primary` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`image_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
INSERT INTO `product_images` VALUES (1,1,'fried_rice.png',1),(2,1,'fried_rice2.png',0),(3,1,'vegetable.png',0),(4,2,'beef_pho.png',1),(5,2,'noodle soup.png',0),(6,2,'noodle soup.png',0),(7,3,'bunCha.png',1),(8,3,'bunCha.png',0),(9,3,'bunCha.png',0),(10,4,'taco.png',1),(11,4,'spring rolls.png',0),(12,4,'spring rolls1.png',0),(13,5,'sausage pizza.png',1),(14,5,'sausage pizza1.png',0),(15,5,'sausage pizza2.png',0),(16,6,'sausage pizza.png',1),(17,6,'sausage pizza1.png',0),(18,6,'sausage pizza2.png',0),(19,7,'seafood pizza2.png',1),(20,7,'seafood pizza.png',0),(21,7,'seafood pizza2.png',0),(22,8,'spaghetti.png',1),(23,8,'spaghetti1.png',0),(24,8,'spaghetti3.png',0),(25,9,'hotpot.png',1),(26,9,'beef hotpot1.png',0),(27,9,'beef hotpot2.png',0),(28,10,'doner.png',1),(29,10,'chesse.png',0),(30,10,'pate.png',0),(31,11,'bunBo.png',1),(32,11,'noodle soup.png',0),(33,11,'buncha.png',0),(34,12,'spring rolls.png',1),(35,12,'spring rolls1.png',0),(36,12,'taco.png',0),(37,13,'flan.png',1),(38,13,'flan1.png',0),(39,13,'flan2.png',0),(40,14,'matcha.png',1),(41,14,'matcha.png',0),(42,14,'matcha.png',0),(43,15,'coffee3.png',1),(44,15,'coffee.png',0),(45,15,'coffee1.png',0),(46,16,'avocado_smoothie.png',1),(47,16,'avocado_smoothie1.png',0),(48,16,'avocado_smoothie2.png',0),(49,17,'peach_tea1.png',1),(50,17,'peach_tea2.png',0),(51,17,'peach_tea3.png',0),(52,18,'orange_juice1.png',1),(53,18,'orange_juice.png',0),(54,18,'orange_juice2.png',0),(55,19,'fried chicken1.png',1),(56,19,'fried chicken2.png',0),(57,19,'fried chicken.png',0),(58,20,'fried_potatoes.png',1),(59,20,'fried_potatoes2.png',1),(60,20,'fried_potatoes1.png',1),(61,21,'hotpot.png',0),(62,21,'beef hotpot.png',0),(63,21,'beef hotpot1.png',0);
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-13 11:21:49
